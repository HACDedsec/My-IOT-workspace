**A Simple python Script to view saved password on your system.**

This script works on both Windows and Linux.
