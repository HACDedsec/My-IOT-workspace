#Automated email python script You can now send emails to multiple people at once easily with only a few clicks using smtplib module in Python

#Requirement Python version 3 and above smtplib json

```bash
pip install smtplib
pip install json
```

Can be run easily using commmand prompt (python automated_email.py)
 -> login as you would for your gmail account( same email and password)
 -> find your way with the intuitive user friendly menu
 (!!!Your passwords and emails are only stored on your local device and no one has access to your information otherwise!!!)
