# Word Generator

## Description
A python script that generates english words that contain 2 or more letters from input

## Usage
Just run gen.py and type in some letters

## Requirements
Python 3