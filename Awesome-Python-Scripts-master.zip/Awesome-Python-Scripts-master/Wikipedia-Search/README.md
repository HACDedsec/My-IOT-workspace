# Wikipedia Search
This app takes input from the user and searches Wikipedia

# Requirements

Python 3 and higher or Python 2 and higher 

Wikipedia Library (https://pypi.org/project/wikipedia/)

# Usage

For Windows users:

```bash
$ python pywikisearch.py
```

For Mac/Linux/Unix users:

```bash
$ ./pywikisearch.py
```
