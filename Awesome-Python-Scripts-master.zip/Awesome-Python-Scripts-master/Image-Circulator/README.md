# Image Circulator
Tiny Python3 script to make your images circular.

## Dependencies
 It requires `python3` and `pillow`.
 To install `pillow`, you need `pip3` or python3.

## Usage
To run, from the command line type:

`python3 image_circulator.py -i INPUT_FILE_PATH -o OUTPUT_FILE_PATH -d DIAMETER_IN_PIXELS`

Or make the script executable.
