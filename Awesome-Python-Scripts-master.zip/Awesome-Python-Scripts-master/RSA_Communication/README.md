# RSA Communication Script

## How to use
To use this script you may first open the script :p
It will take some time, it will generate two BIG prime numbers, and that takes some time.

After it finnishes calculating your keypair, it will print it and ask you if you want to encrypt or decrypt a message.

---

If you want to encrypt, you write "e" and then press enter. The script will ask you for a key (keypair) to encrypt your message, and here you paste the keypair of your correspondant
(the string that shows up at his/her script start).
After you paste the keypair you will write your message, and when you press enter the encrypted message will be printed.

---

If you want to decrypt a message, you write "d" and the press enter. Then the script will ask you for the message to decrypt, wich you are going to paste and press enter.
After you press enter the decrypted message will be displayed :)
