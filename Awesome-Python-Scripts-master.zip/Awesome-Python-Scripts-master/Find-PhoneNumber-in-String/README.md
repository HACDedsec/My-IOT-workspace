# Find Phone Number in a string

A python script that will extract phone numbers in a string

## Requirements
Python 3.7.3

## Usage
$ python Find-PhoneNumber-in-String.py
Enter a Sentence: Call me in this number 403-867-2229