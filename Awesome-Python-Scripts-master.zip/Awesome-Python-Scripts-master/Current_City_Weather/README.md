# Current City Weather
Uses a GET request to retrieve details on your current weather details within your city, simply insert the name of any
city and it will provide details such as current temperature, current wind speed and current weather type.

usage: Go to Current_City_Weather directory and run Weather.py and ad



