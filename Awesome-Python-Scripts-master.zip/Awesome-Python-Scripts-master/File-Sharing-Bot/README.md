# File-Sharing-Bot
File Sharing telegram Bot developed in Python
It is like a centerlized file repository where authorized users can share files and files are available to all the users.
Functionalities and commands can be seen using /help command.
This bot can be directly hosted on Heroku.
