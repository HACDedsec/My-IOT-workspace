Crypt_Socket
==============

Steps:
--------

### #1 - Install third-part library Simple-crypt ###
```pip install simple-crypt```

More information on: https://github.com/andrewcooke/simple-crypt

### #2 - Run server-side script ###
In some terminal window run:
```python cryptSocket_servidor.py```

### #3 - Run client-side script ###
On another terminal window run:
```python cryptSocket_client.py```

#### PS: ####
For some system is needed use python3 instead python
