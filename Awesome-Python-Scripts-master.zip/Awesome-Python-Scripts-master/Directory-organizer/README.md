# Directory-organizer
Organises the files in the given directory according to their type(common extensions).
Unrecognized extensions are kept in the parent directory itself while others are moved to respective new directories like 'Pictures' etc.

usage: Directory-oraganiser.py [-h] path_to_the_directory



