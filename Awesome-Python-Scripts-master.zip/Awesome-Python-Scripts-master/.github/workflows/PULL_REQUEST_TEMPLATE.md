## Description

<!-- Please include a summary of the script. Also include relevant motivation, context and use case. List any dependencies that are required for this change -->


## Checklist
<!-- Remove items that do not apply. For completed items, change [ ] to [x]. -->
- [ ] I have read and followed the [Contribution Guidlines](https://github.com/hastagAB/Awesome-Python-Scripts#contribution-guidelines-) before creating this PR.
- [ ] I've added a new Script
- [ ] Script is tested and running perfectly fine on my system
- [ ] PR is regarding the Documetation
- [ ] This change requires a documentation update



