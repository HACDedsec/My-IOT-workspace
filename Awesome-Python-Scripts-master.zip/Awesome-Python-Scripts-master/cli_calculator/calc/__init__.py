from .calc import sub, mult, div, soma

__all__ = ['sub', 'mult', 'div', 'soma']
