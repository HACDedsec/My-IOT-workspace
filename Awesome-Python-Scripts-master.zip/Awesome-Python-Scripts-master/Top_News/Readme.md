### Cool IT news
This python made script shows top voted news `basic version votes>99` from hackernews. 

### Installation
First of all use 

```
pip install requirements.txt
```

### Run

```
python coolnews.py
```

##
If you want news of more then desired number of votes you can edit
```
Line 29.   if points > 99:
```
