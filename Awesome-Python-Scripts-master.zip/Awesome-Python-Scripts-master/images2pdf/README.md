# images2pdf
this is a small script to make a pdf from list of images.  

### Dependencies:
1- PIL package  
2- fpdf

### how to run :  
1- create a directory with images you want to create a pdf from  
2- name those images with numbers as the order you want  
3- run the script , it will ask you for the directory , and a name for your pdf  

### to do :  
1- modify the position of the image to be at the center of the page  
2- modify the dimensions of the image to fill the page  
3- put some comments on the code  



