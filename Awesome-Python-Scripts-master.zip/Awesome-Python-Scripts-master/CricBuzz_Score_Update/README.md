# Cric-Update
This python script, based on web scraping, fetches the score of the recent cricket matches using Beautiful soup library to scrape the data. 


# How to run

Type in this command in terminal.

    python3 cricbuzz_scrap.py

It will display score updates of all the recent matches.

![](https://d2mxuefqeaa7sj.cloudfront.net/s_78DB49E0B4D273EF775E6D44076B0924AC39C7C9CAE0AA84C9E4F68389263AD8_1532542514744_Screenshot+from+2018-07-25+23-43-29.png)

