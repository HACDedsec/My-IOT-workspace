# Take a Screenshot :

A simple implementation on how to take screenshots .

 #### Required Modules :
  - Numpy
    ```bash
      pip install numpy
    ```
  - Opencv
    ```bash
      pip install opencv-python
    ```
  - Pyautogui
    ```bash
      pip3 install pyautogui --user
    ```
  #### Results :

   ![alt text](https://github.com/moadmmh/Awesome-OpenCV/blob/master/Take_Screenshot/test.png)
