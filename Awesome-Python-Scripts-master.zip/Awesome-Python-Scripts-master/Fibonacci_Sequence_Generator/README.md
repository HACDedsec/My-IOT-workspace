# Python Fibonacci Sequence Generator
This python script will ask you how many numbers do you need to see in the Fibonacci Sequence and generates the sequence based on your input.

## Requirement
Python 3.xx 

## Running the script
```bash
python Fibonacci.py
```