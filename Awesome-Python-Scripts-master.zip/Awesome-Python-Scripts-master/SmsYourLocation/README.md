
<p>this is small python script to send sms to your loved ones....especially for those have very caring mother like mine</p> 
<p>so you can run this script as cron job and it will SMS your currrent location to number you want (note: it should be registered with TWILO)</p>
<p><b>NOTE:you need to make a account in twilo. if you are going to use paid one you will have more options like multiple numbers extra....</b></p>


