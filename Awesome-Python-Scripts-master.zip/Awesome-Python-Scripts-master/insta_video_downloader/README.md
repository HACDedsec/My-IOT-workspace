# Instagram Video Downloader
### Downlaods all the videos from instagram post. User needs to provide instagram post id as parameter
>> Example 

```
python instavideo.py B3NUFfmgRYW
```
>> Example output file

```
B3NUFfmgRYW_0.mp4
```