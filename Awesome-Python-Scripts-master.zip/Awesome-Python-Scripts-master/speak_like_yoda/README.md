# Speak-Like-Yoda

## Description
A python script that translates an input English sentence into Yoda-speak.

## Usage
Run ```python speak_like_yoda.py```. Type in your sentence to get it translated into Yoda-speak.

## Requirements
The script only uses Python's standard modules ```random``` and ```string```, so no additional installation is needed.