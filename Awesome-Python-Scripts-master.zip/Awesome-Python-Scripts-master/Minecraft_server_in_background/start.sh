#!/bin/sh

java -Xmx2048M -Xms2048M -jar server.jar -nogui
