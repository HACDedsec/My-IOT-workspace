# anyZipcrack-dictionary
This python script will crack any zip file using given dictionary file
## Requipment

python 3.++ or  2.++

# Usage
try using the given zip file and dictionary file

## For windows

```bash
$ python zipCrack.py -f evil.zip -d dictionary.txt
```

## For unix/mac/linux

```bash
$ ./zipCrack.py -f evil.zip -d dictionary.txt
```
or that way
```bash
$ python zipCrack.py -f evil.zip -d dictionary.txt
```
