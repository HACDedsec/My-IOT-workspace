# Get information about your favorite TV shows at once 
This python script will make a excel files, with information about every episode from every season of the TV show that you searched for

## Requirement

Python 3.6 onwards
```bash
pip3 install requests
pip3 install xlwt
pip3 install bs4

```

#Usage 
Call python following with the simple algebra problem
```bash
$ python scraper.py
```
Then simply enter the name of the show you want to search for, and then you will find a excel file in the same directory with the name of the show you searched for