# GPS Tracker via GSM using TTGO TCALL Module 
 This is the code for the project called "GPS Tracker with call & SMS feature". The project was made using following Components
 
 1. TTGO TCALL Module(https://www.youtube.com/watch?v=bFm8Pb_M-dE)
 2. Neo6M GPS Module
 3. Battery
 4. ON/OFF Switch
 5. Push buttons
 6. 10k Resistors
 
To know more about this project kindly watch out it's full tutorial video uploaded on my YouTube channel(http://www.youtube.com/techiesms)
 
