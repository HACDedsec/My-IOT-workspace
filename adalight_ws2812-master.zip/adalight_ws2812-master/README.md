Adalight WS2812
===============

This is a fork of Adalight working with WS2811/WS2812 LED using the FastLED library (v 3.1).

FastLED library can be found on Github here : https://github.com/FastLED/FastLED
